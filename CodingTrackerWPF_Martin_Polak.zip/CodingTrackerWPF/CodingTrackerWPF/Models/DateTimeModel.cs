﻿namespace CodingTrackerWPF.Models;

public class DateTimeModel
{
    public DateTime SelectedDate { get; set; }
    public DateTime SelectedTime { get; set; }
}
