﻿namespace CodingTrackerWPF.Enums;

public enum FilterPeriod
{
    Week,
    Month,
    Year
}

