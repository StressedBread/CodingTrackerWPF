﻿using System.Windows.Controls;

namespace CodingTrackerWPF.Views
{
    /// <summary>
    /// Interaction logic for DateTimePickerView.xaml
    /// </summary>
    public partial class DateTimePickerView : UserControl
    {
        public DateTimePickerView()
        {
            InitializeComponent();
        }
    }
}
